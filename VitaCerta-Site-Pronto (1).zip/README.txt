VitaCerta - Site GitHub Pages
--------------------------
index.html = Blog com escudo + frase (modelo Healthline/Examine)
proteina-real/index.html = Pagina de vendas R$14,90

UPLOAD:
1. github.com/vitacerta/VitaCerta--Site
2. Add file > Upload files
3. Arraste index.html + pasta proteina-real
4. Commit to main

Site: https://vitacerta.github.io/VitaCerta--Site/
Vendas: https://vitacerta.github.io/VitaCerta--Site/proteina-real/
